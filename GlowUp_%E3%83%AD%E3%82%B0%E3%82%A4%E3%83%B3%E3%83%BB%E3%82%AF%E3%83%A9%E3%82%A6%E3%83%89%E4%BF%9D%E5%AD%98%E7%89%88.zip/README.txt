GlowUp｜ログイン・クラウド保存対応サイト

重要：このパッケージは公開用のサイト一式です。まだあなたのアカウントに公開・接続はしていません。
ログインとクラウド保存を有効にするには、Supabaseの無料プロジェクトを作成し、設定値を入れる必要があります。

公開までの手順
1. Supabase（https://supabase.com/）でプロジェクトを作成。
2. Project Settings → API（または Connect）から Project URL と anon/publishable key をコピー。
3. index.html の次の2行に設定値を貼り付ける：
   const SUPABASE_URL = 'PASTE_YOUR_SUPABASE_PROJECT_URL_HERE';
   const SUPABASE_ANON_KEY = 'PASTE_YOUR_SUPABASE_ANON_KEY_HERE';
   公開用のanon/publishable keyだけを使い、service_role / secret keyは絶対に入れないでください。
4. SupabaseのSQL Editorで supabase_setup.sql の内容を実行。
5. Supabase Authentication → URL Configuration で、あとで使う公開URLをSite URL / Redirect URLsに設定。
6. GitHub（https://github.com/）で新しい公開リポジトリを作り、index.html をアップロード。
7. Settings → Pages → Deploy from a branch → main / (root) → Save。
8. 発行されたURLを開いて新規登録・ログイン・保存をテスト。

データ保護
- 各ユーザーの記録はログインした本人だけが読み書きできるよう、Row Level Securityを設定します。
- 公開前に必ず別のテストアカウントでも、他人の記録が見えないことを確認してください。
- 本名、学校名、住所、健康上の詳細など、必要のない個人情報は記録しないでください。
- メール認証設定や利用制限はSupabase側の設定に従ってください。
- これはサンプル実装です。公開前に必ず動作確認してください。
